/** Automatically generated file. DO NOT MODIFY */
package login_and_register.ff;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}