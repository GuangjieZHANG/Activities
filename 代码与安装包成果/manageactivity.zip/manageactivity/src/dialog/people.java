package dialog;

class people {

	String name;
	String tele;
	String xueyuan;
	String xuehao;
	
	
	
	
	

	public people() {
		// TODO Auto-generated constructor stub
	}

	
	
	public String getXuehao() {
		return xuehao;
	}
	
	public void setXuehao(String xuehao) {
		this.xuehao = xuehao;
	}
	public String getXueyuan() {
		return xueyuan;
	}

	public void setXueyuan(String xueyuan) {
		this.xueyuan = xueyuan;
	}

	public String getName() {
		return name;
	}

	public String getTele() {
		return tele;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setTele(String tele) {
		this.tele = tele;
	}

}