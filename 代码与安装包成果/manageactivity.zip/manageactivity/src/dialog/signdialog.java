package dialog;

import java.util.ArrayList;

import login_and_register.ff.R;

import webservice.webservice_activity_info;

import com.example.manageactivity.activity_info;
import com.example.manageactivity.sign_success;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable.Orientation;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

public class signdialog extends Dialog{

	EditText name1, tele1, name2, tele2, name3, tele3, xuehao1, xuehao2,
			xuehao3;
	Spinner spinner_xueyuan1, spinner_xueyuan2, spinner_xueyuan3;
	// ���ӳ�Ա��ť
	Button finish;
	String activityid = null;

	ArrayList<String> xue;
	ArrayAdapter<String> ad;

	static Context context;
	LinearLayout layout;
	
	  private signdialogListener listener;   

	public signdialog(Context c) {
		// TODO Auto-generated constructor stub
		super(c);
		xue = new ArrayList<String>();
		context = c;

	}
	
	  public interface signdialogListener{   
	         public void onClick(View view);   
	     }   
	  
	   
	   

	private Handler han = new Handler() {

		public void handleMessage(android.os.Message msg) {

			switch (msg.arg1) {
			case 0:
				// ȷ�����յ�����Ϣ

				activityid = msg.getData().getString("activityid");

				break;

			default:
				break;
			}

		};

	};

	private View.OnClickListener clicklistener = new View.OnClickListener() {

		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			int a = arg0.getId();

			switch (a) {
			// �����ȷ����ťʱ�����ݴ��������б���
			case R.id.sighdialog_finish:

				ArrayList<EditText> namelist = new ArrayList<EditText>();
				ArrayList<EditText> telelist = new ArrayList<EditText>();
				ArrayList<EditText> xuehaolist = new ArrayList<EditText>();

				ArrayList<Spinner> spinlist = new ArrayList<Spinner>();
				ArrayList<people> peoplelist = new ArrayList<people>();
				namelist.add(name1);
				namelist.add(name2);
				namelist.add(name3);
				telelist.add(tele1);
				telelist.add(tele2);
				telelist.add(tele3);

				xuehaolist.add(xuehao1);
				xuehaolist.add(xuehao2);

				xuehaolist.add(xuehao3);

				spinlist.add(spinner_xueyuan1);
				spinlist.add(spinner_xueyuan2);
				spinlist.add(spinner_xueyuan3);

				int i = 0;

				for (EditText e : namelist) {
					// ��������list��������ֲ�Ϊ�գ���ȡ������˵���Ϣ
					if (!e.getText().toString().endsWith("")) {
						people p = new people();
						p.setName(e.getText().toString());
						p.setTele(telelist.get(i).getText().toString());
						p.setXueyuan(spinlist.get(i).toString());
						p.setXuehao(xuehaolist.get(i).toString());
						peoplelist.add(p);
					}
					i++;
				}

				System.out.println(123);
				// �����ݴ���ȥ

				webservice_activity_info wai = new webservice_activity_info();

				String xuehaosign = peoplelist.get(0).getXuehao();

				// ��������Ҫ���ı�ע����Ϣ������ע����ϢӦ�ð������˵�һλ�����ߵ�ʣ�µ����е���Ϣ
				// ��Ϊ��һλ������Ϊ�ӳ� �ǵ�½���Լ�����Ϣ �����ݿ���
				String beizhuinfoString = "";

				// ���磺2014303367/����/130909090900/������΢����ѧԺ.2014303346/�Ź��/13098759999/�����ѧԺ.
				for (int j = 1; j < 3; j++) {

					people p = peoplelist.get(j);
					beizhuinfoString = beizhuinfoString + p.getXuehao() + "/"
							+ p.getName() + "/" + p.getTele() + "/"
							+ p.getXueyuan() + ".";

				}

				System.out.println(beizhuinfoString);

				if (wai.signupactivity(xuehaosign, activityid, beizhuinfoString)
						.equals("�����ɹ�")) {
					// ҳ����ת�������ɹ�ҳ��

					Intent in = new Intent();
					in.setClass(context, sign_success.class);
					getContext().startActivity(in);
				} else {

					// ����ʧ��
				}

				break;

			default:
				break;
			}
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

		setContentView(R.layout.signdialog);

		init();

	}

	private void init() {
		// TODO Auto-generated method stub

		name1 = (EditText) findViewById(R.id.signdialog_name1);
		name2 = (EditText) findViewById(R.id.signdialog_name2);
		name3 = (EditText) findViewById(R.id.signdialog_name3);

		tele1 = (EditText) findViewById(R.id.signdialog_tele1);
		tele2 = (EditText) findViewById(R.id.signdialog_tele2);
		tele3 = (EditText) findViewById(R.id.signdialog_tele3);

		xuehao1 = (EditText) findViewById(R.id.signdialog_xuehao1);
		xuehao2 = (EditText) findViewById(R.id.signdialog_xuehao2);

		xuehao3 = (EditText) findViewById(R.id.signdialog_xuehao3);

		spinner_xueyuan1 = (Spinner) findViewById(R.id.signdialog_spinner_xueyuan1);

		spinner_xueyuan2 = (Spinner) findViewById(R.id.signdialog_spinner_xueyuan2);

		spinner_xueyuan3 = (Spinner) findViewById(R.id.signdialog_spinner_xueyuan3);

		finish= (Button) findViewById(R.id.sighdialog_finish);
		
		finish.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				click();
				
				
				
			}

		});
		
		// �ڴ˴����ӱ����ĳ�Ա��ѧԺ��Ϣ
		xue.add("������΢����ѧԺ");
		xue.add("�����ѧԺ");

		
		
		ad = new ArrayAdapter<String>(context,
				android.R.layout.simple_spinner_item, xue);
		spinner_xueyuan1.setAdapter(ad);
		spinner_xueyuan2.setAdapter(ad);
		spinner_xueyuan3.setAdapter(ad);

	}

	private void click() {
		// TODO Auto-generated method stub
		
		System.out.println(213);
		ArrayList<EditText> namelist = new ArrayList<EditText>();
		ArrayList<EditText> telelist = new ArrayList<EditText>();
		ArrayList<EditText> xuehaolist = new ArrayList<EditText>();

		ArrayList<Spinner> spinlist = new ArrayList<Spinner>();
		ArrayList<people> peoplelist = new ArrayList<people>();
		namelist.add(name1);
		namelist.add(name2);
		namelist.add(name3);
		telelist.add(tele1);
		telelist.add(tele2);
		telelist.add(tele3);

		xuehaolist.add(xuehao1);
		xuehaolist.add(xuehao2);

		xuehaolist.add(xuehao3);

		spinlist.add(spinner_xueyuan1);
		spinlist.add(spinner_xueyuan2);
		spinlist.add(spinner_xueyuan3);

		int i = 0;

		for (EditText e : namelist) {
			// ��������list��������ֲ�Ϊ�գ���ȡ������˵���Ϣ
			if (!e.getText().toString().equals("")) {
				people p = new people();
				
			
				p.setName(e.getText().toString());
				p.setTele(telelist.get(i).getText().toString());
				p.setXueyuan((String)spinlist.get(i).getSelectedItem());
				
				
				p.setXuehao(xuehaolist.get(i).getText().toString());
				
				peoplelist.add(p);
			
			
			}
			i++;
		}

		
		// �����ݴ���ȥ

		webservice_activity_info wai = new webservice_activity_info();

		String xuehaosign = peoplelist.get(0).getXuehao();

		// ��������Ҫ���ı�ע����Ϣ������ע����ϢӦ�ð������˵�һλ�����ߵ�ʣ�µ����е���Ϣ
		// ��Ϊ��һλ������Ϊ�ӳ� �ǵ�½���Լ�����Ϣ �����ݿ���
		String beizhuinfoString = "";

		// ���磺2014303367/����/130909090900/������΢����ѧԺ.2014303346/�Ź��/13098759999/�����ѧԺ.
		for (int j = 1; j < peoplelist.size(); j++) {

			people p = peoplelist.get(j);
			beizhuinfoString = beizhuinfoString + p.getXuehao() + "/"
					+ p.getName() + "/" + p.getTele() + "/"
					+ p.getXueyuan() + ".";

		}

		System.out.println(beizhuinfoString);

		if (wai.signupactivity(xuehaosign, activityid, beizhuinfoString)
				.equals("�����ɹ�")) {
			// ҳ����ת�������ɹ�ҳ��

			Intent in = new Intent();
			in.putExtra("StudentId", xuehaosign);
			
			in.setClass(context, sign_success.class);
			getContext().startActivity(in);
			activity_info.h.sendEmptyMessage(1);
			
			
		} else {

			// ����ʧ��
		}

	}
	public Handler getHandler() {
		return han;
	}

	

	

}
