package webservice;

public class Constants {
	public static String serverPath = "http://139.196.125.5:8080/b/";
	//public static String serverPath = "http://192.168.1.106:8080/chenjing/";
}
