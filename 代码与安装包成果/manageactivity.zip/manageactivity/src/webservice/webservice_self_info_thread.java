package webservice;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;

import javax.net.ssl.HttpsURLConnection;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.util.Base64;

public class webservice_self_info_thread extends Thread {
	String url;
	String name;
	String grade;
	String stuNo;
	String stuTel;

	public webservice_self_info_thread(String url, String name, String grade,
			String stuNo, String stuTel) {
		this.url = url;
		this.name = name;
		this.grade = grade;
		this.stuNo = stuNo;
		this.stuTel = stuTel;
	}

	@Override
	public void run() {
		doPost();
	}
/*
	public void doGet() {
		url = url + "name=" + name + "&grade=" + grade + "&stuNo=" + stuNo
				+ "&stuTel=" + stuTel;

		HttpGet httpget = new HttpGet(url);
		try {

			HttpClient httpClient = new DefaultHttpClient();
			HttpResponse response = httpClient.execute(httpget);
			// �����Ӧ״̬
			// ״̬��Ϊ200��������404�ͻ��˳�����505����������response.getStatusLine().getStatusCode()
			/*
			 * ����ֱ�Ӱ�response.tostring,�õ�entity��Ȼ��õ����������ٽ��ж�ȡ
			 */
/*			HttpEntity entity = response.getEntity();
			InputStream inputStream = entity.getContent();
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					inputStream));
			String line = reader.readLine();

			System.out.println(line);

		} catch (Exception e) {

			e.printStackTrace();

		}

	}
*/
	//���ַ�������Base64����
	public String base64(String content) {
		try {
			content = Base64.encodeToString(content.getBytes("utf-8"),
					Base64.DEFAULT);
			content = URLEncoder.encode(content);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return content;

	}
	
	
	public void doGet(){
//		String content = "name=" + name + "&grade=" + grade + "&stuNo=" + stuNo
//				+ "&stuTel=" + stuTel;
//		url = url + base64(content);
		name = URLEncoder.encode(name);
		grade = URLEncoder.encode(grade);
		stuNo = URLEncoder.encode(stuNo);
		stuTel = URLEncoder.encode(stuTel);
		url = url + "name=" + name + "&grade=" + grade + 
				"&stuNo=" + stuNo + "&stuTel=" + stuTel;
//		url = base64(url);
		try {
			URL httpUrl = new URL(url);
			HttpURLConnection conn = (HttpURLConnection) httpUrl.openConnection();
			
			
			InputStreamReader in = new InputStreamReader(conn.getInputStream());
			BufferedReader buffer = new BufferedReader(in);
			String inputLine = null;
			String result="";
			while ((inputLine = buffer.readLine()) != null ){
				result += inputLine + "\n";
			}
			in.close();
			conn.disconnect();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void doPost() {
		try {
			URL httpUrl = new URL(url);
			HttpsURLConnection conn;
			conn = (HttpsURLConnection) httpUrl.openConnection();
			conn.setRequestMethod("POST");
			conn.setReadTimeout(5000);
			OutputStream out = conn.getOutputStream();

			conn.setDoOutput(true);
			conn.setRequestProperty("Content-Type",
					"application/x-www-form-urlencoded");
			// conn.setRequestProperty("Content-Length",
			// String.valueOf(str.getBytes().length));

			// ������������ύ������
			String content = "name=" + name + "&grade=" + grade + "&stuNo="
					+ stuNo + "&stuTel=" + stuTel;
			out.write(content.getBytes());

			BufferedReader reader = new BufferedReader(new InputStreamReader(
					conn.getInputStream()));
			StringBuffer sb = new StringBuffer();
			String str;

			while ((str = reader.readLine()) != null) {
				sb.append(str);
			}

			System.out.println(sb.toString());
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
