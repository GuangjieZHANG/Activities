package webservice;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

public class webservice_activity_info {
	//10.0.2.2
	private static String path = Constants.serverPath ;
	//private static String path="http://139.196.125.5:8080/b/";
//	private static String path="http://10.22.39.178:8081/b/";
	HttpClient httpClient = new DefaultHttpClient();
	
	
	public String signupactivity(String memberId,String activityId,String othermessage) {
		
		 HttpGet httpget = new HttpGet(path+"servlet_activity_info_signupactivity" +
		 		"?memberId="+memberId+"&activityId="+activityId+"&othermessage="+othermessage
		 );
		try {
			HttpResponse response = httpClient.execute(httpget);
			// �����Ӧ״̬
			// ״̬��Ϊ200��������404�ͻ��˳�����505����������response.getStatusLine().getStatusCode()
			/*
			 * ����ֱ�Ӱ�response.tostring,�õ�entity��Ȼ��õ����������ٽ��ж�ȡ
			 */

			HttpEntity entity = response.getEntity();

			InputStream inputStream = entity.getContent();

			BufferedReader reader = new BufferedReader(
			new InputStreamReader(inputStream));
			String line = reader.readLine();

			System.out.println(line);
			
			
			 return line;
		
			 
			 
		}catch(Exception e){
			
			e.printStackTrace();
			return   "����ʧ��";
		}
	
	
	
	
	
	
	
	
}	
	
	
	
	
	
	
}
