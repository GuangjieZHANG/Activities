package webservice;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;


public class webService_mine_collected {

	private static String PATH = Constants.serverPath +"servlet_mine_collected_getActivity";
	private static URL url;

	static {
		try {
			url = new URL(PATH);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @param params
	 *            ��д��url�Ĳ���
	 * @param encode
	 *            �ֽڱ���
	 * @return
	 */
	public String sendPostMessage(Map<String, String> params, String encode) {
		// ��ΪStringBuffer��ʼ�����ַ���
		StringBuffer buffer = new StringBuffer();
		try {
			if (params != null && !params.isEmpty()) {
				for (Map.Entry<String, String> entry : params.entrySet()) {
					// ���ת�����
					buffer.append(entry.getKey())
							.append("=")
							.append(URLEncoder.encode(entry.getValue(), encode))
							.append("&");
				}
				buffer.deleteCharAt(buffer.length() - 1);
			}
	
			HttpURLConnection urlConnection = (HttpURLConnection) url
					.openConnection();
			urlConnection.setConnectTimeout(10000);
			urlConnection.setRequestMethod("POST");
			urlConnection.setDoInput(true);// ��ʾ�ӷ�������ȡ����
			urlConnection.setDoOutput(true);// ��ʾ�������д����
			// ����ϴ���Ϣ���ֽڴ�С�Լ�����
			byte[] mydata = buffer.toString().getBytes();
			// ��ʾ������������������ı�����
			urlConnection.setRequestProperty("Content-Type",
					"application/x-www-form-urlencoded");
			urlConnection.setRequestProperty("Content-Length",
					String.valueOf(mydata.length));
			// ��������,��������������
			OutputStream outputStream = urlConnection.getOutputStream();
			outputStream.write(mydata, 0, mydata.length);
			outputStream.close();
			// ��÷�������Ӧ�Ľ����״̬��
			int responseCode = urlConnection.getResponseCode();
			if (responseCode == 200) {
				return changeInputStream(urlConnection.getInputStream(), encode);
			}
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}

	/**
	 * ��һ��������ת����ָ��������ַ���
	 * 
	 * @param inputStream
	 * @param encode
	 * @return
	 */
	private static String changeInputStream(InputStream inputStream,
			String encode) {
		// TODO Auto-generated method stub
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		byte[] data = new byte[1024];
		int len = 0;
		String result = "";
		if (inputStream != null) {
			try {
				while ((len = inputStream.read(data)) != -1) {
					outputStream.write(data, 0, len);
				}
				result = new String(outputStream.toByteArray(), encode);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return result;
	}
	
	/**
	 * ��ôӷ������˵�json��ʽ������
	 * @param maps
	 * @return
	 */
	public String getJsonData(Map<String, String> maps){
		webService_mine_collected ws = new webService_mine_collected();
		String info = ws.sendPostMessage(maps, "utf-8");
		return info;
	}

	/**
	 * ��json��ʽ�����ݽ���
	 * @param info
	 * @return
	 * @throws JSONException
	 */
	public List<Map<String, Object>> getData(String info,Context context)
			throws JSONException {
		// TODO Auto-generated method stub
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		JSONArray array = new JSONArray(info);

		for (int i = 0; i < array.length(); i++) {
				
			JSONObject jsonMap = array.getJSONObject(i);
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("id", jsonMap.getString("id"));
			map.put("name", jsonMap.getString("name"));
			map.put("location", jsonMap.getString("location"));
			//�˴�ֻ�Ǵӷ������˻�ȡ���ַ�����ʽ��ͼƬ������			
			String imgStr = jsonMap.getString("image");
			map.put("img",imgStr); 
			
			
			/**************************/
			map.put("time",jsonMap.getString("stime")+" -- "+jsonMap.getString("etime"));
			map.put("organizers",jsonMap.getString("mainOrg"));
			if(jsonMap.getString("cnum").equals("")){
				map.put("cnum","0");
			}else{
				map.put("cnum",jsonMap.getString("cnum"));
			}
			if(jsonMap.getString("snum").equals("")){
				map.put("snum","0");
			}else{
				map.put("snum",jsonMap.getString("snum"));
			}
			
	
			/*************************/
			list.add(map);
		}
		return list;
	}
}