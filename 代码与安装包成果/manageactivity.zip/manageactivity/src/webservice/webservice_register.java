package webservice;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import login_and_register.ff.register;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

public class webservice_register {

	
	
	private static String path=Constants.serverPath;
//	private static String path="http://10.22.39.178:8081/b/";
	HttpClient httpClient = new DefaultHttpClient();

	public String  register(String name,String phonenumber,String 
			password,String studentId){
		
		
		
		 HttpGet httpget = new HttpGet(path+"servlet_register?name="+name+"&phonenumber="+phonenumber
				 +"&password="+password+"&studentId="+studentId);
			try {
				HttpResponse response = 
						
						httpClient.execute(httpget);
				// �����Ӧ״̬
				// ״̬��Ϊ200��������404�ͻ��˳�����505����������response.getStatusLine().getStatusCode()
				/*
				 * ����ֱ�Ӱ�response.tostring,�õ�entity��Ȼ��õ����������ٽ��ж�ȡ
				 */

				HttpEntity entity = response.getEntity();

				InputStream inputStream = entity.getContent();

				BufferedReader reader = new BufferedReader(
				new InputStreamReader(inputStream));
				String line = reader.readLine();

				System.out.println(line);
				return line;
			}catch(Exception e){
				
				e.printStackTrace();
				return null;
			}
		
		
		
		
		
		
		
		
		
	}
	
	
}
