package webservice;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class webservice_self_info_show {
	String url;
	String[] ans;
	public webservice_self_info_show(String url) {
		this.url = url;
	}
	
	public String[] doGet(){
		URL httpUrl;
		try {
			httpUrl = new URL(url);
			HttpURLConnection conn = (HttpURLConnection) httpUrl.openConnection();
			
			InputStreamReader in = new InputStreamReader(conn.getInputStream());
			BufferedReader buffer = new BufferedReader(in);
			String inputLine = null;
			String result="";
			while ((inputLine = buffer.readLine()) != null ){
				result += inputLine + "\n";
			}
			ans = result.split("_");
			in.close();
			conn.disconnect();
			
		} catch (MalformedURLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ans;
	}
	
}
