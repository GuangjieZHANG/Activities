package mine;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import login_and_register.ff.R;

import org.json.JSONException;

import webservice.webService_mine_collected;
import zrc.widget.ZrcListView;

import zrc.widget.SimpleFooter;
import zrc.widget.SimpleHeader;
import zrc.widget.ZrcListView.OnStartListener;

import com.example.manageactivity.MainActivity;

import com.nostra13.universalimageloader.cache.disc.impl.UnlimitedDiscCache;
import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator;
import com.nostra13.universalimageloader.cache.memory.impl.UsingFreqLimitedMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;
import com.nostra13.universalimageloader.core.download.BaseImageDownloader;
import com.nostra13.universalimageloader.utils.StorageUtils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

/**
 * @author S
 * 
 */
public class mine_collected extends Activity {

	private Button backbutton;

	private ZrcListView listView;
	private CollectListViewAdapter mAdapter;
	private Context mContext = this;
	// �������̸߳�������
	private static Handler handler = new Handler();

	private DisplayImageOptions options; //ͼƬ�첽����
	

	String stuID = null;

	// ���û����ļ���
	private String cachePath = "mine_collected_Cache.dat";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.mine_collected);
		stuID = getIntent().getExtras().getString("StudentId");
		backbutton = (Button) findViewById(R.id.button_collectedActivity_to_mineindex);
		backbutton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

//				Intent intent = new Intent();
//				intent.putExtra("StudentId", stuID);
//				intent.setClass(mine_collected.this, MainActivity.class);
//				mine_collected.this.startActivity(intent);
				mine_collected.this.finish();

			}
		});
		File cacheDir = StorageUtils.getOwnCacheDirectory(getApplicationContext(), "/ActivityManager/users/images/Cache");  
		ImageLoaderConfiguration config = new ImageLoaderConfiguration  
				     .Builder(this)  
				     .memoryCacheExtraOptions(480, 800) // max width, max height���������ÿ�������ļ�����󳤿�  
				     .discCacheExtraOptions(480, 800, CompressFormat.JPEG, 75, null) // Can slow ImageLoader, use it carefully (Better don't use it)/���û������ϸ��Ϣ����ò�Ҫ�������  
				     .threadPoolSize(3)//�̳߳��ڼ��ص�����  
				     .threadPriority(Thread.NORM_PRIORITY - 2)  
				     .denyCacheImageMultipleSizesInMemory()  
				     .memoryCache(new UsingFreqLimitedMemoryCache(2 * 1024 * 1024)) // You can pass your own memory cache implementation/�����ͨ���Լ����ڴ滺��ʵ��  
				     .memoryCacheSize(2 * 1024 * 1024)    
				     .discCacheSize(50 * 1024 * 1024)    
				     .discCacheFileNameGenerator(new Md5FileNameGenerator())//�������ʱ���URI������MD5 ����  
				    .tasksProcessingOrder(QueueProcessingType.LIFO)  
				     .discCacheFileCount(100) //������ļ�����  
			     .discCache(new UnlimitedDiscCache(cacheDir))//�Զ��建��·��  
				     .defaultDisplayImageOptions(DisplayImageOptions.createSimple())  
				     .imageDownloader(new BaseImageDownloader(this, 5 * 1000, 30 * 1000)) // connectTimeout (5 s), readTimeout (30 s)��ʱʱ��  
				     .writeDebugLogs() // Remove for release app  
				    .build();//��ʼ����  
		
		ImageLoader.getInstance().init(config);//ȫ�ֳ�ʼ��������  

		
		
		options = new DisplayImageOptions.Builder()
		.showImageOnLoading(R.drawable.ic_stub)
		.showImageForEmptyUri(R.drawable.ic_empty)
		.showImageOnFail(R.drawable.ic_error)
		.cacheInMemory(true)
		.cacheOnDisc(true)
		.considerExifParams(true)
		.displayer(new RoundedBitmapDisplayer(20))
		.build();
		

		listView = (ZrcListView) findViewById(R.id.listView_collectedActivity);
		
		 // ��������ˢ�µ���ʽ����ѡ�������û��Header���޷�����ˢ�£�
        SimpleHeader header = new SimpleHeader(this);
        header.setTextColor(0xff0066aa);
        header.setCircleColor(0xff33bbee);
        listView.setHeadable(header);
        
        // ����Ĭ��ƫ��������Ҫ����ʵ��͸�����������ܡ�����ѡ��
        float density = getResources().getDisplayMetrics().density;
        listView.setFirstTopOffset((int) (50 * density));
        
        // ���ü��ظ������ʽ����ѡ��
        SimpleFooter footer = new SimpleFooter(this);
        footer.setCircleColor(0xff33bbee);
        listView.setFootable(footer);

        // �����б�����ֶ�������ѡ��
        listView.setItemAnimForTopIn(R.anim.topitem_in);
        listView.setItemAnimForBottomIn(R.anim.bottomitem_in);
        
        // ����ˢ���¼��ص�����ѡ��
        listView.setOnRefreshStartListener(new OnStartListener() {
            @Override
            public void onStart() {
            	new Thread(new DataThread()).start();
            }
        });


        listView.setEmptyView(findViewById(R.id.collected_empty_txt)); //û������ʱ��ʾ
        listView.refresh(); // ��������ˢ��
		

	}

	// ���߳̽������ݣ����߳��޸�����
	public class DataThread implements Runnable {
		List<Map<String, Object>> datas;

		@Override
		public void run() {

			boolean isInternet = false;
			String cacheStr = "";
			try {
				cacheStr = readDataFromCahe();
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				cacheStr = "";
			}

			Map<String, String> map = new HashMap<String, String>();
			// ����������͵����ݣ�����memberId������ղصĻ������
			map.put("memberId", stuID);

			webService_mine_collected wmc = new webService_mine_collected();

			// ����Ƿ�����
			if (isWifi(mine_collected.this) || checkNetwork()) {
				isInternet = true;
			}

			// �������������ȡ���ݲ�д�뻺�棬����ֱ�Ӵӻ����ж�ȡ
			if (isInternet) {

				try {
					String jsonData = wmc.getJsonData(map);
					if (!jsonData.equals("") && jsonData != null) {
						datas = wmc.getData(jsonData, mine_collected.this);
						//if (!cacheStr.equals(jsonData)) {
							writeDataToCahe(jsonData);
							writeToSd(jsonData);
						//}
					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} else {

				try {

					if (!cacheStr.equals("") && cacheStr != null) {
						datas = wmc.getData(cacheStr, mine_collected.this);
					}

				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			handler.post(new Runnable() {
				@Override
				public void run() {

					mAdapter = new CollectListViewAdapter(mine_collected.this,
							datas,options,stuID,(isWifi(mine_collected.this) || checkNetwork()));
					listView.setAdapter(mAdapter);
					if((isWifi(mine_collected.this) || checkNetwork())){
						listView.setRefreshSuccess("���سɹ�"); // ֪ͨ���سɹ�
						//listView.startLoadMore(); // ����LoadingMore����
					}else{
						listView.setRefreshFail("����ʧ��");
					}
					
	              

				}
			});
		}
	}

	/************************************************************************************/
	/**
	 * �򻺴��ļ���д����
	 * 
	 * @param data
	 */
	private void writeDataToCahe(String data) {
		FileOutputStream fos = null;
		try {
			fos = openFileOutput(stuID+cachePath, Context.MODE_PRIVATE);
			fos.write(data.getBytes());
			fos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * ������д�뵽sd����
	 * 
	 * @param text
	 *            Ҫ������ַ�
	 */
	public void writeToSd(String text) {
		if (Environment.getExternalStorageState().equals(
				Environment.MEDIA_MOUNTED)) {
			File sdCardDir = Environment.getExternalStorageDirectory();// ��ȡSDCardĿ¼
			String rootPath = sdCardDir.getPath()+"/ActivityManager/users/"+stuID;
		    File rootFileDir=new File(rootPath);
		    if(!rootFileDir.exists())
		    	rootFileDir.mkdirs();
		    
			File sdFile = new File(rootFileDir, "/mine_collected.dat");

			try {
				FileOutputStream fos = new FileOutputStream(sdFile,true);
				fos.write(text.getBytes());
				fos.close();
//				Toast.makeText(mine_collected.this, "�ɹ����浽sd��",
//						Toast.LENGTH_LONG).show();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	/**
	 * �ӻ����ļ��ж�����
	 * 
	 * @return
	 * @throws FileNotFoundException
	 */
	private String readDataFromCahe() throws FileNotFoundException {
		FileInputStream in = null;
		try {
			in = openFileInput(stuID+cachePath);
			ByteArrayOutputStream outStream = new ByteArrayOutputStream();
			byte[] buffer = new byte[1024];
			int len = 0;
			while ((len = in.read(buffer)) != -1) {
				outStream.write(buffer, 0, len);
			}
			outStream.close();
			in.close();
			byte[] data = outStream.toByteArray();
			String name = new String(data);
			return name;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}

	/**
	 * ��������Ƿ�Ϊ wifi
	 * 
	 * @param mContext
	 * @return
	 */
	private boolean isWifi(Context mContext) {
		ConnectivityManager connectivityManager = (ConnectivityManager) mContext
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo activeNetInfo = connectivityManager.getActiveNetworkInfo();
		if (activeNetInfo != null
				&& activeNetInfo.getType() == ConnectivityManager.TYPE_WIFI) {
			return true;
		}
		return false;
	}

	/**
	 * ��������Ƿ�Ϊ2G��3G
	 * 
	 * @return
	 */
	private boolean checkNetwork() {
		ConnectivityManager connManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		if (connManager.getActiveNetworkInfo() != null) {
			return connManager.getActiveNetworkInfo().isAvailable();
		}
		return false;
	}

}
