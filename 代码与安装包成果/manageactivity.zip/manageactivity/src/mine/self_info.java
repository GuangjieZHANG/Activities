package mine;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Calendar;

import android.support.v4.app.Fragment;
import webservice.Constants;
import webservice.webservice_self_info_show;
import webservice.webservice_self_info_thread;
import login_and_register.ff.R;

import com.example.manageactivity.MainActivity;
import com.example.manageactivity.mine_fragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.provider.MediaStore.Audio.Media;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;

public class self_info extends Activity {
	String root = Environment.getExternalStorageDirectory().getAbsolutePath();
	String picPath = root + File.separator + "head_icon.jpg";

	String stuID = null;

	String name=null;
	String id=null;
	String grade=null;
	String telephone=null;
			

	Button save_info_button;
	Button back;
	EditText editname, editgrade, editstID, editphonenumber;
	ImageView headIcon;
	private static final int PHOTO_REQUEST_CAREMA = 1;
	private static final int PHOTO_REQUEST_GALLERY = 2;
	private static final int PHOTO_REQUEST_CUT = 3;
	private File tempFile;
	String PHOTO_FILE_NAME = "temp_photo.jpg";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.mine_self_info);
		if (android.os.Build.VERSION.SDK_INT > 9) {
			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
					.permitAll().build();
			StrictMode.setThreadPolicy(policy);
		}

		stuID = getIntent().getExtras().getString("StudentId");

//		webservice_self_info_show w =
//
//		new webservice_self_info_show(Constants.serverPath
//				+ "self_info_show?studentId=" + stuID);
//
//		String ans[] = w.doGet();
//		
//		name = ans[0];
//		id = ans[1];
//		grade = ans[2];
//		telephone = ans[3];

		// System.out.println(stuID+"dsak");
		// ��ʼ��
		init();
		
		// ��ʾ֮ǰ��ͷ��
		showHeadIcon();
		// ����ԭʼ��Ϣ
		showInfo();
		// �س������¼�
		enterListen(editname);
		enterListen(editgrade);
		enterListen(editstID);
		enterListen(editphonenumber);
	
		// ���水ť
		save_info_button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// String url = "http://10.22.39.178:8081/b/self_info_servl?";
				String url = Constants.serverPath+"self_info_servl?";
				new webservice_self_info_thread(url, editname.getText()
						.toString(), editgrade.getText().toString(), editstID
						.getText().toString(), editphonenumber.getText()
						.toString()).doGet();

				Toast toast=Toast.makeText(getApplicationContext(),
						"�ѱ���", Toast.LENGTH_SHORT); 			
		
				toast.show();
			}
		});

		// ���ذ�ť
		back.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
//				Intent intent = new Intent();
//				intent.putExtra("StudentId", stuID);
//				intent.setClass(self_info.this, MainActivity.class);
//				self_info.this.startActivity(intent);
				self_info.this.finish();
			}
		});

		headIcon.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// ��ͷ��
				changeHeadIcon();
			}
		});

	}

	public void enterListen(EditText editText) {
		editText.setOnEditorActionListener(new OnEditorActionListener() {
			@Override
			public boolean onEditorAction(TextView v, int actionId,
					KeyEvent event) {
				return (event.getKeyCode() == KeyEvent.KEYCODE_ENTER);
			}
		});
	}

	public void showInfo() {
		String url = Constants.serverPath+"self_info_show?";
		// String url ="https://10.22.39.178:8081/b/self_info_show?";
		webservice_self_info_show show = new webservice_self_info_show(url
				+ "studentId=" + stuID);
		String[] ans = show.doGet();
		editname.setText(ans[0]);
		editstID.setText(stuID);
		editstID.setFocusable(false);
		editstID.setFocusableInTouchMode(false);
		editgrade.setText(ans[2]);
		editphonenumber.setText(ans[3]);
	}

	public void showHeadIcon() {
		File file = new File(picPath);
		if (file.exists()) {
			String fileName = picPath;
			Bitmap bm = BitmapFactory.decodeFile(fileName);
			headIcon.setImageBitmap(bm);
		}
	}

	private void changeTheme() {
		Calendar c = Calendar.getInstance();
		System.out.println(c.get(Calendar.HOUR_OF_DAY));
		if (c.get(Calendar.HOUR_OF_DAY) < 18
				&& c.get(Calendar.HOUR_OF_DAY) >= 6) {
			headIcon.setImageResource(R.drawable.llla);
		} else {
			headIcon.setImageResource(R.drawable.ic_launcher);
		}
	}

	private void changeHeadIcon() {
		final CharSequence[] items = { "���", "����" };
		AlertDialog dlg = new AlertDialog.Builder(self_info.this)
				.setTitle("ѡ����Ƭ")
				.setItems(items, new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int item) {
						// �����item�Ǹ���ѡ��ķ�ʽ
						if (item == 0) {
							Intent intent = new Intent(Intent.ACTION_PICK);
							intent.setType("image/*");
							intent.setAction(Intent.ACTION_GET_CONTENT);
							startActivityForResult(intent,
									PHOTO_REQUEST_GALLERY);
						} else {
							Intent intent = new Intent(
									MediaStore.ACTION_IMAGE_CAPTURE);

							tempFile = new File(Environment
									.getExternalStorageDirectory(),
									PHOTO_FILE_NAME);
							Uri uri = Uri.fromFile(tempFile);
							intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
							startActivityForResult(intent, PHOTO_REQUEST_CAREMA);
						}
					}
				}).create();
		dlg.show();
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == PHOTO_REQUEST_GALLERY) {
			if (data != null) {
				Uri uri = data.getData();
				Log.e("ͼƬ·��??", data.getData() + "");
				crop(uri);
			}
		} else if (requestCode == PHOTO_REQUEST_CAREMA) {
			if (Environment.getExternalStorageState().equals(
					Environment.MEDIA_MOUNTED)) {
				crop(Uri.fromFile(tempFile));
			} else {
				Toast.makeText(self_info.this, "δ�ҵ��洢��", Toast.LENGTH_SHORT)
						.show();
			}
		} else if (requestCode == PHOTO_REQUEST_CUT) {
			if (data != null) {
				final Bitmap bitmap = data.getParcelableExtra("data");
				headIcon.setImageBitmap(bitmap);
				// ����ͼƬ�� internal storage
				/*
				 * FileOutputStream outputStream; try { ByteArrayOutputStream
				 * out = new ByteArrayOutputStream(); //�ڶ���������ѹ����
				 * bitmap.compress(Bitmap.CompressFormat.JPEG,50,out);
				 * out.flush(); // out.close(); //final byte[] buffer =
				 * out.toByteArray(); //OutputStream.write(buffer); outputStream
				 * = self_info.this.openFileOutput("_head_icon.jpg",Context.
				 * MODE_PRIVATE); out.writeTo(outputStream); out.close();
				 * outputStream.close(); } catch (IOException e) { // TODO
				 * Auto-generated catch block e.printStackTrace(); }
				 */
				// ����ͼƬ�� external storage
				byte[] bs = bitmapToByte(bitmap);
				try {
					File file = new File(picPath);
					file.createNewFile();
					FileOutputStream fos = new FileOutputStream(picPath);
					fos.write(bs);
					fos.flush();
					fos.close();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			// if(tempFile != null && tempFile.exists())
			// tempFile.delete();
		}
	}

	// Bitmapתbyte����
	public byte[] bitmapToByte(Bitmap bitmap) {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		bitmap.compress(Bitmap.CompressFormat.JPEG, 50, out);
		return out.toByteArray();
	}

	// ͷ��ü�
	private void crop(Uri uri) {
		Intent intent = new Intent("com.android.camera.action.CROP");
		intent.setDataAndType(uri, "image/*");
		intent.putExtra("crop", "true");
		intent.putExtra("aspectX", 1);
		intent.putExtra("aspectY", 1);
		intent.putExtra("outputX", 250);
		intent.putExtra("outputY", 250);
		intent.putExtra("outputFormat", "JPEG");
		intent.putExtra("noFaceDetection", true);
		intent.putExtra("return-data", true);
		startActivityForResult(intent, PHOTO_REQUEST_CUT);
	}

	private void init() {

		save_info_button = (Button) findViewById(R.id.button_save_personalnfo);
		back = (Button) findViewById(R.id.button_personalinfo_to_mineindex);
		editstID = (EditText) findViewById(R.id.editView_useracademyId);
		editstID.setText(id);
		
		editgrade = (EditText) findViewById(R.id.editView_college);
		
		
		
		editname = (EditText) findViewById(R.id.editView_username);
		
		editname.setText(name);
		
		
		editphonenumber = (EditText) findViewById(R.id.editView_phonenumber);
		editphonenumber.setText(telephone);
		
		
		headIcon = (ImageView) findViewById(R.id.imageView_personhead);

	}
}
