package mine;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import webservice.Constants;

import login_and_register.ff.R;

import com.nostra13.universalimageloader.cache.disc.impl.UnlimitedDiscCache;
import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator;
import com.nostra13.universalimageloader.cache.memory.impl.UsingFreqLimitedMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.ImageLoadingListener;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;
import com.nostra13.universalimageloader.core.assist.SimpleImageLoadingListener;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;
import com.nostra13.universalimageloader.core.download.BaseImageDownloader;
import com.nostra13.universalimageloader.utils.StorageUtils;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class ActivityOnMainListViewAdapter extends BaseAdapter{
	
	private Context context;
	private ArrayList<String> mName;
	private ArrayList<String> mLoc;
	private ArrayList<String> mOrg;
	private ArrayList<String> mIntro;
	private ArrayList<String> mId;
	private ArrayList<String> mImg;
	private LayoutInflater mInflater;
	
	private ImageLoadingListener animateFirstListener = new AnimateFirstDisplayListener();
	protected ImageLoader imageLoader = ImageLoader.getInstance();
	private DisplayImageOptions options; //ͼƬ�첽����

	public ActivityOnMainListViewAdapter(Context context, ArrayList<String> mName,ArrayList<String> mLoc,ArrayList<String> mOrg,
			ArrayList<String> mIntro, ArrayList<String> mId,ArrayList<String> mImg) {
		// TODO Auto-generated constructor stub
		this.context = context;
		this.mName = mName;
		this.mLoc = mLoc;
		this.mOrg = mOrg;
		this.mIntro = mIntro;
		this.mId = mId;
		this.mImg = mImg;
		mInflater = LayoutInflater.from(context);
		File cacheDir = StorageUtils.getOwnCacheDirectory(context, "/ActivityManager/users/images/Cache");  
		ImageLoaderConfiguration config = new ImageLoaderConfiguration  
				     .Builder(context)  
				     .memoryCacheExtraOptions(480, 800) // max width, max height���������ÿ�������ļ�����󳤿�  
				     .discCacheExtraOptions(480, 800, CompressFormat.JPEG, 75, null) // Can slow ImageLoader, use it carefully (Better don't use it)/���û������ϸ��Ϣ����ò�Ҫ�������  
				     .threadPoolSize(3)//�̳߳��ڼ��ص�����  
				     .threadPriority(Thread.NORM_PRIORITY - 2)  
				     .denyCacheImageMultipleSizesInMemory()  
				     .memoryCache(new UsingFreqLimitedMemoryCache(2 * 1024 * 1024)) // You can pass your own memory cache implementation/�����ͨ���Լ����ڴ滺��ʵ��  
				     .memoryCacheSize(2 * 1024 * 1024)    
				     .discCacheSize(50 * 1024 * 1024)    
				     .discCacheFileNameGenerator(new Md5FileNameGenerator())//�������ʱ���URI������MD5 ����  
				    .tasksProcessingOrder(QueueProcessingType.LIFO)  
				     .discCacheFileCount(100) //������ļ�����  
			     .discCache(new UnlimitedDiscCache(cacheDir))//�Զ��建��·��  
				     .defaultDisplayImageOptions(DisplayImageOptions.createSimple())  
				     .imageDownloader(new BaseImageDownloader(context, 5 * 1000, 30 * 1000)) // connectTimeout (5 s), readTimeout (30 s)��ʱʱ��  
				     .writeDebugLogs() // Remove for release app  
				    .build();//��ʼ����  
		
		ImageLoader.getInstance().init(config);//ȫ�ֳ�ʼ��������  

		
		
		options = new DisplayImageOptions.Builder()
		.showImageOnLoading(R.drawable.ic_stub)
		.showImageForEmptyUri(R.drawable.ic_empty)
		.showImageOnFail(R.drawable.ic_error)
		.cacheInMemory(true)
		.cacheOnDisc(true)
		.considerExifParams(true)
		.displayer(new RoundedBitmapDisplayer(20))
		.build();
		
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mName.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return mName.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}


	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		
		ViewHolder holder = null;
		final int id = position;		
		if(convertView == null){
			holder = new ViewHolder();
			
			convertView = mInflater.inflate(R.layout.activity_fragment_listview_item, null);
			holder.act_name = (TextView) convertView.findViewById(R.id.activity_f_act_name);
			holder.act_location = (TextView) convertView.findViewById(R.id.activity_f_act_location);
			holder.act_organizers = (TextView) convertView.findViewById(R.id.activity_f_act_organizers);
			holder.act_intro = (TextView) convertView.findViewById(R.id.activity_f_intro);
			holder.act_id = (TextView) convertView.findViewById(R.id.activity_f_act_id);
			holder.act_img = (ImageView) convertView.findViewById(R.id.activity_f_act_img);
			convertView.setTag(holder);
			
		}else{
			 holder = (ViewHolder)convertView.getTag();
		}
		
		
        holder.act_name.setText(mName.get(position));
        holder.act_location.setText("�ص㣺"+mLoc.get(position));
        holder.act_organizers.setText("�ٰ췽��"+mOrg.get(position));  
        holder.act_intro.setText("����ܣ�"+mIntro.get(position)); 
        holder.act_id.setText(mId.get(position)); 
        
        String server = Constants.serverPath +"get_act_img?imgurl=";
			
		String imgNames = mImg.get(position);
		//Toast.makeText(getActivity(), imgNames, Toast.LENGTH_LONG).show();
		
		imgNames = imgNames.replace("|", "/");
		String[] imgUrls = imgNames.split("/");	
		
        imageLoader.displayImage(server + imgUrls[0],
        		holder.act_img, options, animateFirstListener);
		
		return convertView;
	}
	
	

	public final class ViewHolder{
		public ImageView act_img;
		public TextView act_name;
		public TextView act_location;
		public TextView act_organizers;
		public TextView act_intro;
		public TextView act_id;
		
	}
	
	private static class AnimateFirstDisplayListener extends
	SimpleImageLoadingListener {

static final List<String> displayedImages = Collections
		.synchronizedList(new LinkedList<String>());

@Override
public void onLoadingComplete(String imageUri, View view,
		Bitmap loadedImage) {
	if (loadedImage != null) {
		ImageView imageView = (ImageView) view;
		boolean firstDisplay = !displayedImages.contains(imageUri);
		if (firstDisplay) {
			FadeInBitmapDisplayer.animate(imageView, 500);
			displayedImages.add(imageUri);
		}
	}
}
}


}
