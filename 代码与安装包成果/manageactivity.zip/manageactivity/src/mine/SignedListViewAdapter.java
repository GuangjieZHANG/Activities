package mine;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;


import webservice.Constants;
import webservice.webService_mine_signed;

import login_and_register.ff.R;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.daimajia.swipe.SimpleSwipeListener;
import com.daimajia.swipe.SwipeLayout;

import com.daimajia.swipe.adapters.BaseSwipeAdapter;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.ImageLoadingListener;
import com.nostra13.universalimageloader.core.assist.SimpleImageLoadingListener;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;

public class SignedListViewAdapter extends BaseSwipeAdapter {

	private Context mContext;
	private List<Map<String, Object>> mData;

	private ImageLoadingListener animateFirstListener = new AnimateFirstDisplayListener();
	protected ImageLoader imageLoader = ImageLoader.getInstance();
	private DisplayImageOptions options;
	private String stuId;
	private boolean isInternet;
	// �������̸߳�������
	private static Handler handler = new Handler();

	public SignedListViewAdapter(Context mContext) {
		this.mContext = mContext;
	}

	public SignedListViewAdapter(Context mContext,
			List<Map<String, Object>> data, DisplayImageOptions options,
			String stuId, boolean isInternet) {
		this.mData = data;
		this.mContext = mContext;
		this.options = options;
		this.stuId = stuId;
		this.isInternet = isInternet;
	}

	@Override
	public int getSwipeLayoutResourceId(int position) {
		return R.id.signed_swipe;
	}

	@Override
	public View generateView(final int position, ViewGroup parent) {
		final View v = LayoutInflater.from(mContext).inflate(
				R.layout.mine_signed_listview_item, null);

		final SwipeLayout swipeLayout = (SwipeLayout) v
				.findViewById(getSwipeLayoutResourceId(position));
		swipeLayout.addSwipeListener(new SimpleSwipeListener() {
			@Override
			public void onOpen(SwipeLayout layout) {
				// YoYo.with(Techniques.Tada).duration(500).delay(100).playOn(layout.findViewById(R.id.trash));
			}
		});
		/*
		 * swipeLayout.setOnDoubleClickListener(new
		 * SwipeLayout.DoubleClickListener() {
		 * 
		 * @Override public void onDoubleClick(SwipeLayout layout, boolean
		 * surface) { Toast.makeText(mContext, "DoubleClick",
		 * Toast.LENGTH_SHORT).show(); } });
		 */
		v.findViewById(R.id.signed_trash).setOnClickListener(
				new View.OnClickListener() {
					@Override
					public void onClick(View view) {

						TextView act_id = (TextView) v
								.findViewById(R.id.signed_act_id);
						String id = act_id.getText().toString();

						for (int i = 0; i < mData.size(); i++) {
							Map<String, Object> map = mData.get(i);
							if (map.get("id") != null
									&& map.get("id").equals(id)) {

								new Thread(new DeleteThread(i, swipeLayout,id))
										.start();
								break;
							}
						}

					}
				});

		return v;
	}

	// ���߳̽������ݣ����߳��޸�����
	public class DeleteThread implements Runnable {
		boolean isHasDelete;
		int item;
		SwipeLayout swipeLayout;
		String deleteFailReason;
		String actId;

		public DeleteThread(int item, SwipeLayout swipeLayout,String actId) {
			this.item = item;
			this.swipeLayout = swipeLayout;
			this.actId = actId;
		}

		@Override
		public void run() {

			Map<String, String> map = new HashMap<String, String>();
			// ����������͵����ݣ�����memberId������ղصĻ������
			map.put("memberId", stuId);
			map.put("deletewhich", actId);

			webService_mine_signed wmc = new webService_mine_signed();
			isHasDelete = false;

			// �������������ȡ���ݲ�д�뻺�棬����ֱ�Ӵӻ����ж�ȡ
			if (isInternet) {
				String deleteStr = wmc.getJsonData(map);

				if (deleteStr != null && deleteStr.equals("delete ok")) {
					isHasDelete = true;
				} else {
					deleteFailReason = "����������ɾ��ʧ�ܣ�";
				}

			} else {
				deleteFailReason = "���������ӣ�ɾ��ʧ�ܣ�";
			}

			handler.post(new Runnable() {
				@Override
				public void run() {

					if (isHasDelete) {
						swipeLayout.close();
						mData.remove(item);
						notifyDataSetChanged();
						Toast.makeText(mContext, "ɾ���ɹ���", Toast.LENGTH_SHORT)
								.show();
					} else {
						Toast.makeText(mContext, deleteFailReason,
								Toast.LENGTH_SHORT).show();
					}

				}
			});
		}
	}

	@Override
	public void fillValues(int position, View convertView) {
        String server = Constants.serverPath +"get_act_img?imgurl=";
		ImageView act_img = (ImageView) convertView.findViewById(R.id.signed_act_img);
		imageLoader.displayImage(server + (String) mData.get(position).get("img"),
				act_img, options, animateFirstListener);

		TextView act_name = (TextView) convertView.findViewById(R.id.signed_act_name);
		act_name.setText((String) mData.get(position).get("name"));

		
		

		TextView act_time = (TextView) convertView.findViewById(R.id.signed_act_time);
		act_time.setText("ʱ�䣺"+(String) mData.get(position).get("time"));
		
		TextView act_location = (TextView) convertView
				.findViewById(R.id.signed_act_location);
		act_location.setText("�ص㣺"+(String) mData.get(position).get("location"));
		
		TextView act_organizers = (TextView) convertView
				.findViewById(R.id.signed_act_organizers);
		act_organizers.setText("�ٰ췽��"+(String) mData.get(position).get("organizers"));


		TextView collect_num = (TextView) convertView
				.findViewById(R.id.signed_num);
		collect_num.setText((String) mData.get(position).get("cnum") + " �ղ�"
				+ " | " + (String) mData.get(position).get("snum") + " ���� | �ѱ���");

		TextView act_id = (TextView) convertView.findViewById(R.id.signed_act_id);
		act_id.setText((String) mData.get(position).get("id"));

	}

	@Override
	public int getCount() {
		return mData.size();
	}

	@Override
	public Object getItem(int position) {
		return null;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	private static class AnimateFirstDisplayListener extends
			SimpleImageLoadingListener {

		static final List<String> displayedImages = Collections
				.synchronizedList(new LinkedList<String>());

		@Override
		public void onLoadingComplete(String imageUri, View view,
				Bitmap loadedImage) {
			if (loadedImage != null) {
				ImageView imageView = (ImageView) view;
				boolean firstDisplay = !displayedImages.contains(imageUri);
				if (firstDisplay) {
					FadeInBitmapDisplayer.animate(imageView, 500);
					displayedImages.add(imageUri);
				}
			}
		}
	}

}
