package login_and_register.ff;

import webservice.webService_mine_collected;
import webservice.webservice_login;
import webservice.webservice_register;

import com.example.manageactivity.MainActivity;

import com.example.manageactivity.activity_info;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

public class login extends Activity {

	EditText username, password;

	Button login_button, register_button;
	
	Button unsign_btn;
	
	String ID, pass;

	ProgressBar  p;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.login);
		if (android.os.Build.VERSION.SDK_INT > 9) {
			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
					.permitAll().build();
			StrictMode.setThreadPolicy(policy);
		}

		init();
		p.setVisibility(8);
		// ע�ᰴť�ĵ���¼�
		register_button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				Intent intent = new Intent();
				intent.setClass(login.this, register.class);
				login.this.startActivity(intent);

			}
		});

		// ��¼��ť�ĵ���¼�

		login_button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				ID = username.getText().toString();
				pass = password.getText().toString();

				webservice_login wl = new webservice_login();

				String result = wl.login(pass, ID);

				if (result.equals("��¼�ɹ�")) {

					Intent intent = new Intent();
					intent.setClass(login.this, MainActivity.class);
					intent.putExtra("StudentId", ID);
					login.this.startActivity(intent);

					login.this.finish();

				} else {

				}

			}
		});
		
		
		
		//��㿴�� �����ť
		unsign_btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
		
				p.setVisibility(0);
				ID = "not_sign";
				pass = "not_sign";
				Intent intent = new Intent();
				intent.setClass(login.this, MainActivity.class);
				intent.putExtra("StudentId", ID);
				login.this.startActivity(intent);
				login.this.finish();
			}
		});

	}

	private void init() {
		// TODO Auto-generated method stub
		p = (ProgressBar) findViewById(R.id.login_wait_bar);
		password = (EditText) findViewById(R.id.login_password);
		username = (EditText) findViewById(R.id.login_username);

		login_button = (Button) findViewById(R.id.login_login);
		register_button = (Button) findViewById(R.id.login_register);
		unsign_btn = (Button) findViewById(R.id.login_unsign);
	}
}
