package login_and_register.ff;

import com.example.manageactivity.MainActivity;

import webservice.webservice_register;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class register extends Activity {

	EditText name, phonenumber, password, confirmpassword, studentId;

	Button confirm, cancel;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.register);
		if (android.os.Build.VERSION.SDK_INT > 9) {
			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
					.permitAll().build();
			StrictMode.setThreadPolicy(policy);
		}

		init();
		confirm.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				// if(password.getText().equals(confirmpassword.getText().toString()))
				//
				//
				// {
				if (!name.getText().toString().equals("")
						&& !phonenumber.getText().toString().equals("")
						&& !password.getText().toString().equals("")
						&& !studentId.getText().toString().equals("")

				) {

					System.out.println("1");
					System.out.println(name.getText().toString()
							+ phonenumber.getText().toString()
							+ password.getText().toString()
							+ studentId.getText().toString());

					webservice_register wr = new webservice_register();
					if (wr.register(name.getText().toString(),
							phonenumber.getText().toString(),
							password.getText().toString(),
							studentId.getText().toString()).equals("ע��ɹ�")) {

						System.out.println(name.getText().toString()
								+ phonenumber.getText().toString()
								+ password.getText().toString()
								+ studentId.getText().toString());
						// ��ӡ��� ע��ɹ�
						Intent intent = new Intent();
						intent.setClass(register.this, login.class);
						register.this.startActivity(intent);
						register.this.finish();
					} else {
						// ��ӡ��� ע��ʧ��
					}
					// }else{
					// //��ӡ��� �������벻һ��
					// name.setText("");
					// phonenumber.setText("");
					// confirmpassword.setText("");
					// studentId.setText("");
					// password.setText("");
					// }
				}else{
					
					
					Toast toast=Toast.makeText(getApplicationContext(),
							"ע����Ϣ������", Toast.LENGTH_SHORT); 			
			
					toast.show();
					
				}

			}

		});

		cancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				name.setText("");
				phonenumber.setText("");
				confirmpassword.setText("");
				studentId.setText("");
				password.setText("");

			}
		});

	}

	private void init() {
		// TODO Auto-generated method stub
		name = (EditText) findViewById(R.id.stu_name);
		phonenumber = (EditText) findViewById(R.id.stu_phonenumber);
		password = (EditText) findViewById(R.id.stu_password);
		confirmpassword = (EditText) findViewById(R.id.stu_repassword);
		studentId = (EditText) findViewById(R.id.stu_id);
		confirm = (Button) findViewById(R.id.button_registe);
		cancel = (Button) findViewById(R.id.button_cancel);
	}
}
