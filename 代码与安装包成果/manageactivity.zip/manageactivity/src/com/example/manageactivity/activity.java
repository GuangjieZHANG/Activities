package com.example.manageactivity;

public class activity {

	
	
	private String name;
	private String introduction;
	private String location;
	private String activityId;
	private String department;
	private String imgName;
	
	public String getActivityId() {
		return activityId;
	}
	
	
	public String getDepartment() {
		return department;
	}
	
	
	public String getIntroduction() {
		return introduction;
	}
	
	public String getName() {
		return name;
	}
	
	public String getLocation() {
		return location;
	}
	
	
	public void setdepartment(String department1) {
		department = department1;
	}
	
	public void setname(String name1) {
		name = name1;
	}
	public void setactivityId(String activityId1) {
		activityId=activityId1;
	}
	public void setintroduction(String introduction1) {
		introduction = introduction1;
	}

	public void setlocation(String location1) {
		location = location1;
	}
	
	public void setImg(String img){
		imgName = img;
	}
	public String getImg(){
		return imgName;
	}
	
	
	
}
