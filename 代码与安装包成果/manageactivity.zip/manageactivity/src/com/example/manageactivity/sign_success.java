package com.example.manageactivity;

import login_and_register.ff.R;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

//�����ɹ�ҳ��
public class sign_success extends Activity {

	// ��ť
	Button backbutton, button_to_signedactivity;
	TextView successinfo;
	String stuID = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_info_sign_success);

		stuID = getIntent().getExtras().getString("StudentId");
		
		backbutton = (Button) findViewById(R.id.backButton_success_to_main);
		button_to_signedactivity = (Button) findViewById(R.id.button_successSign_to_signedActivity);
		successinfo = (TextView) findViewById(R.id.textView_success_signinfo);

		successinfo.setText("��ϲ��ɹ��μӸû");

		// ��ť�ļ����¼�

		backbutton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent();
				intent.putExtra("StudentId", stuID);
				intent.setClass(sign_success.this, MainActivity.class);
				sign_success.this.startActivity(intent);
				sign_success.this.finish();

			}
		});

		button_to_signedactivity.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

			}
		});

	}
}
