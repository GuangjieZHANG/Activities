package com.example.manageactivity;

import java.io.File;
import java.nio.channels.GatheringByteChannel;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import com.nostra13.universalimageloader.cache.disc.impl.UnlimitedDiscCache;
import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator;
import com.nostra13.universalimageloader.cache.memory.impl.UsingFreqLimitedMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.ImageLoadingListener;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;
import com.nostra13.universalimageloader.core.assist.SimpleImageLoadingListener;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;
import com.nostra13.universalimageloader.core.download.BaseImageDownloader;
import com.nostra13.universalimageloader.utils.StorageUtils;

import dialog.signdialog;

import login_and_register.ff.R;
import login_and_register.ff.login;
import mine.self_info;

import webservice.Constants;
import webservice.webservice_activity_info;
import webservice.webservice_mine_signup;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class activity_info extends Activity{

	String stuID = null;

	TextView introduTextView;
	Button backButton_info_to_main;
	Button button_sign;
	ImageView imageView_activity_info;

	String activityId = null;
	Context c;
	static Activity a;

	//private List<ImageView> images = new ArrayList<>();
	/******************************************** 20170430 *********************************************/
	int imgSize = 0;
	private String imgNames;
	private DisplayImageOptions options; // ͼƬ�첽����
	private ImageLoadingListener animateFirstListener = new AnimateFirstDisplayListener();
	protected ImageLoader imageLoader = ImageLoader.getInstance();

	/******************************************** 20170430 *********************************************/

	public static Handler h = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			switch (msg.what) {
			case 1:

				a.finish();

				break;

			default:
				break;
			}
		}

	};
//
//	private Handler handler = new Handler() {
//		@Override
//		public void handleMessage(Message msg) {
//			switch (msg.what) {
//			case 0:
//				imageView_activity_info = images.get(msg.what);
//				//imageView_activity_info.setImage(images[msg.what]);
//				break;
//			case 1:
//				imageView_activity_info = images.get(msg.what);
//				//imageView_activity_info.setImage(images[msg.what]);
//				break;
//			case 2:
//				imageView_activity_info = images.get(msg.what);
//				//imageView_activity_info.setImage(images[msg.what]);
//				break;
//			}
//		}
//	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_info);

		stuID = getIntent().getExtras().getString("StudentId");
		// ���ܴ���������introduction��ͼƬ��
		Intent intent = getIntent();
		String introdoction = intent.getStringExtra("introduction");
		activityId = intent.getStringExtra("activityId");
		imgNames = intent.getStringExtra("activityImg");
		
		/******************************************** 20170430 *********************************************/
		initAscnyImgOption();
		/******************************************** 20170430 *********************************************/
		init();
		

		introduTextView.setText(introdoction);

		// ���ذ�ť�ĵ�������¼�
		backButton_info_to_main.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

//				Intent intent = new Intent();
//				intent.putExtra("StudentId", stuID);
//				intent.setClass(activity_info.this, MainActivity.class);
//				activity_info.this.startActivity(intent);
				activity_info.this.finish();
			}
		});

		// ������ť�ļ����¼�
		button_sign.setOnClickListener(new OnClickListener() {
			// dialog����ʾ
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				// ����Ѿ���½��
				if (!stuID.equals("not_sign")) {
					// dialog����ʾ

					System.out.println("login");
					signdialog s = new signdialog(c);

					s.show();
					System.out.println("1");
					// ���Ի�����ʾ����������handler�ķ�ʽ���д�ֵ
					Message m = new Message();
					m.arg1 = 0;
					Bundle b = new Bundle();
					b.putString("activityid", activityId);
					m.setData(b);
					s.getHandler().sendMessage(m);

				} else
					ret_login();

			}
		});

//		// ͼƬ�任�߳�����
//		image_change_Thread t1 = new image_change_Thread();
//		t1.start();

	}

	// �ص���¼
	private void ret_login() {
		// dialog����ʾ
		AlertDialog.Builder builder = new Builder(activity_info.this);
		builder.setMessage("����û�е�¼");
		builder.setTitle("��ȷ��");
		builder.setNegativeButton("��¼", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				Intent intent = new Intent();
				intent.setClass(activity_info.this, login.class);
				activity_info.this.startActivity(intent);
				activity_info.this.finish();
			}
		});
		builder.setPositiveButton("ȡ��", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub

			}
		});

		builder.create().show();
	}

	
	
//	// ͼƬ�任�߳�
//
//	class image_change_Thread extends Thread {
//
//		@Override
//		public void run() {
//			// TODO Auto-generated method stub
//			super.run();
//			int i = 0;
//			while (true) {
//				if (i == 3) {
//
//					i = 0;
//				}
//				handler.sendEmptyMessage(i++);
//				try {
//					Thread.sleep(5000);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//
//			}
//
//		}
//
//	}

	// ��ʼ��

	private void init() {
		// TODO Auto-generated method stub

		c = this;
		a = this;
		introduTextView = (TextView) findViewById(R.id.textView_activity_info);
		backButton_info_to_main = (Button) findViewById(R.id.backButton_info_to_main);
		c = this;
		imageView_activity_info = (ImageView) findViewById(R.id.imageView_activity_info);
		
		 String server = Constants.serverPath +"get_act_img?imgurl=";
			
		/********************************************20170430*********************************************/
		imgNames = imgNames.replace("|", "/");
		String[] imgUrls = imgNames.split("/");
		imgSize = imgUrls.length;
		
		imageLoader.displayImage(server + imgUrls[0],
				imageView_activity_info, options, animateFirstListener);
//		for(int i = 0; i < imgSize; i++){
//			ImageView tmpimgview = new ImageView(this);
//			
//			images.add(tmpimgview);
//		}
		

		/********************************************20170430*********************************************/
			

		button_sign = (Button) findViewById(R.id.button_sign);

	}

	/******************************************** 20170430 *********************************************/
	private void initAscnyImgOption() {
		File cacheDir = StorageUtils.getOwnCacheDirectory(
				getApplicationContext(), "/ActivityManager/users/images/Cache");
		ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(
				this)
				.memoryCacheExtraOptions(480, 800)
				// max width, max height���������ÿ�������ļ�����󳤿�
				.discCacheExtraOptions(480, 800, CompressFormat.JPEG, 75, null)
				// Can slow ImageLoader, use it carefully (Better don't use
				// it)/���û������ϸ��Ϣ����ò�Ҫ�������
				.threadPoolSize(3)
				// �̳߳��ڼ��ص�����
				.threadPriority(Thread.NORM_PRIORITY - 2)
				.denyCacheImageMultipleSizesInMemory()
				.memoryCache(new UsingFreqLimitedMemoryCache(2 * 1024 * 1024))
				// You can pass your own memory cache
				// implementation/�����ͨ���Լ����ڴ滺��ʵ��
				.memoryCacheSize(2 * 1024 * 1024)
				.discCacheSize(50 * 1024 * 1024)
				.discCacheFileNameGenerator(new Md5FileNameGenerator())
				// �������ʱ���URI������MD5 ����
				.tasksProcessingOrder(QueueProcessingType.LIFO)
				.discCacheFileCount(100)
				// ������ļ�����
				.discCache(new UnlimitedDiscCache(cacheDir))
				// �Զ��建��·��
				.defaultDisplayImageOptions(DisplayImageOptions.createSimple())
				.imageDownloader(
						new BaseImageDownloader(this, 5 * 1000, 30 * 1000)) // connectTimeout
																			// (5
																			// s),
																			// readTimeout
																			// (30
																			// s)��ʱʱ��
				.writeDebugLogs() // Remove for release app
				.build();// ��ʼ����

		ImageLoader.getInstance().init(config);// ȫ�ֳ�ʼ��������

		options = new DisplayImageOptions.Builder()
				.showImageOnLoading(R.drawable.ic_stub)
				.showImageForEmptyUri(R.drawable.ic_empty)
				.showImageOnFail(R.drawable.ic_error).cacheInMemory(true)
				.cacheOnDisc(true).considerExifParams(true)
				.displayer(new RoundedBitmapDisplayer(20)).build();
	}

	private static class AnimateFirstDisplayListener extends
			SimpleImageLoadingListener {

		static final List<String> displayedImages = Collections
				.synchronizedList(new LinkedList<String>());

		@Override
		public void onLoadingComplete(String imageUri, View view,
				Bitmap loadedImage) {
			if (loadedImage != null) {
				ImageView imageView = (ImageView) view;
				boolean firstDisplay = !displayedImages.contains(imageUri);
				if (firstDisplay) {
					FadeInBitmapDisplayer.animate(imageView, 500);
					displayedImages.add(imageUri);
				}
			}
		}
	}
	/******************************************** 20170430 *********************************************/

	
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
	
	
	
		 if ((keyCode == KeyEvent.KEYCODE_BACK)) {  
         activity_info.this.finish();  
            return false;  
         }
		
		
	    	return false;
	
	}
	
	
	
	
	
}
