package com.example.manageactivity;

import java.util.ArrayList;

import login_and_register.ff.R;
import mine.mine_collected;
import mine.mine_signed;
import mine.self_info;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class mine_fragment extends Fragment {

	View layoutoftryView;

	ListView listView_of_mine_info;

	// Intent i = new Intent();

	String stuID = null;

	@Override
	public View onCreateView(LayoutInflater inflater,
			@Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		layoutoftryView = inflater.inflate(R.layout.mine_fragment, container,
				false);

		listView_of_mine_info = (ListView) layoutoftryView
				.findViewById(R.id.listView_mine_info);
		// list_mineָ�����ҵ�ҳ����Ҫ��ʾ��item
		ArrayList<String> list_mine = new ArrayList<String>();
		list_mine.add("������Ϣ");
		list_mine.add("�ѱ���");
		list_mine.add("���ղ�");
		stuID = getActivity().getIntent().getExtras().getString("StudentId");
System.out.println(stuID);
		ArrayAdapter<String> ad1 = new ArrayAdapter<String>(this.getActivity(),
				android.R.layout.simple_list_item_1, list_mine);

		listView_of_mine_info.setAdapter(ad1);
		// �����Ǹ��ҵ�ҳ����г�ʼ��

		// �¼�����¼�
		listView_of_mine_info.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub

				switch (position) {
				case 0:
					Intent intent = new Intent();
					intent.setClass(getActivity(), self_info.class);
					Bundle b = new Bundle();
					b.putString("StudentId", stuID);
					intent.putExtras(b);

					getActivity().startActivity(intent);
					//getActivity().finish();
					break;
				case 1:
					Intent intent2 = new Intent();
					intent2.setClass(getActivity(), mine_signed.class);
					Bundle b1 = new Bundle();
					b1.putString("StudentId", stuID);
					intent2.putExtras(b1);
					getActivity().startActivity(intent2);
					//getActivity().finish();
					break;
				case 2:
					Intent intent3 = new Intent();
					intent3.setClass(getActivity(), mine_collected.class);
					Bundle b2 = new Bundle();
					b2.putString("StudentId", stuID);
					intent3.putExtras(b2);
					getActivity().startActivity(intent3);
					//getActivity().finish();
					break;

				default:
					break;
				}

			}

		});

		return layoutoftryView;
	}
}
