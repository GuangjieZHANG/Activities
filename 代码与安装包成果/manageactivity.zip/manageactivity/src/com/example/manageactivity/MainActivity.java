package com.example.manageactivity;

import login_and_register.ff.R;
import login_and_register.ff.login;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;

public class MainActivity extends FragmentActivity implements OnClickListener {

	// bottom����İ�ť
	private LinearLayout mTabactivity;
	private LinearLayout mTabmine;
	private LinearLayout mTabothers;

	// �м��Ҫ��ʾ��ҳ��
	private Fragment mTab1;
	private Fragment mTab2;
	private Fragment mTab3;

	String stuID;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);
		if (android.os.Build.VERSION.SDK_INT > 9) {
			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
					.permitAll().build();
			StrictMode.setThreadPolicy(policy);
		}

		// ��ʼ�����
		init();
		// ��ʼ������¼�
		initEvent();

		setSelect(0);

	}

	private void initEvent() {
		// TODO Auto-generated method stub
		mTabactivity.setOnClickListener(this);
		mTabmine.setOnClickListener(this);
		mTabothers.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.id_tab_activity:
			setSelect(0);
			break;
		case R.id.id_tab_mine:
			if (stuID.equals("not_sign")) {
				//������ʾ
				ret_login();
			} else
				setSelect(1);
			break;
		case R.id.id_tab_others:
			setSelect(2);
			break;
		}
	}
	
	private void ret_login() {
		// dialog����ʾ
		AlertDialog.Builder builder = new Builder(MainActivity.this);
		builder.setMessage("����û�е�¼");
		builder.setTitle("��ȷ�ϵ�¼");
		builder.setNegativeButton("��¼", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				Intent intent = new Intent();
				intent.setClass(MainActivity.this, login.class);
				MainActivity.this.startActivity(intent);
				MainActivity.this.finish();
			}
		});
		builder.setPositiveButton("ȡ��", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub

			}
		});

		builder.create().show();
	}


	private void setSelect(int i) {

		Bundle bundleFra = new Bundle();
		bundleFra.putString("StudentId", stuID);

		// ������������

		FragmentManager fm = getSupportFragmentManager();
		FragmentTransaction transaction = fm.beginTransaction();
		hideFragment(transaction);

		switch (i) {
		case 0:
			if (mTab1 == null) {
				mTab1 = new activity_fragment();

				mTab1.setArguments(bundleFra); // ������

				transaction.add(R.id.id_content, mTab1);

			} else {
				transaction.show(mTab1);
			}
			break;

		case 1:
			if (mTab2 == null) {
				mTab2 = new mine_fragment();
				mTab2.setArguments(bundleFra); // ������
				transaction.add(R.id.id_content, mTab2);
			} else {
				transaction.show(mTab2);
			}
			break;
		case 2:
			if (mTab3 == null) {
				mTab3 = new other_fragment();
				mTab3.setArguments(bundleFra); // ������
				transaction.add(R.id.id_content, mTab3);
			} else {
				transaction.show(mTab3);
			}
			break;

		default:
			break;

		}

		transaction.commit();

	}

	private void hideFragment(FragmentTransaction transaction) {
		// TODO Auto-generated method stub
		if (mTab1 != null) {
			transaction.hide(mTab1);
		}
		if (mTab2 != null) {
			// mTab2=null;
			transaction.hide(mTab2);
		}
		if (mTab3 != null) {
			transaction.hide(mTab3);
		}
	}

	private void init() {
		// TODO Auto-generated method stub
		mTabactivity = (LinearLayout) findViewById(R.id.id_tab_activity);
		mTabmine = (LinearLayout) findViewById(R.id.id_tab_mine);
		mTabothers = (LinearLayout) findViewById(R.id.id_tab_others);

		// ����id

		Intent intent = getIntent();
		Bundle bundleAc = intent.getExtras();
		stuID = bundleAc.getString("StudentId");

	}
	
	
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
	
	
	
		 if ((keyCode == KeyEvent.KEYCODE_BACK)) {  
			 
			 AlertDialog.Builder builder = new Builder(MainActivity.this);
				builder.setMessage("��ȷ���˳���");
				builder.setTitle("��ȷ���˳�");
				builder.setNegativeButton("��", new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						
						MainActivity.this.finish();
					}
				});
				builder.setPositiveButton("��", new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub

					}
				});

				builder.create().show();	 
			 
			 
       
            return false;  
         }
		
		
	    	return false;
	
	}
	

}
