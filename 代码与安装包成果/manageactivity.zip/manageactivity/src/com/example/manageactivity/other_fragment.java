package com.example.manageactivity;

import login_and_register.ff.R;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebView.FindListener;
import android.widget.ImageView;

public class other_fragment extends Fragment implements OnClickListener {

	View layoutoftryView;
	ImageView ruijieliuliang, ruijietaocan, aoxiang, xiaoche, xiaoli, paocao;
	WebView mobView;

	@Override
	public View onCreateView(LayoutInflater inflater,
			@Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		layoutoftryView = inflater.inflate(R.layout.add, container, false);
		init();

		
		
		
		
		
		return layoutoftryView;
	}

	private void init() {
		// TODO Auto-generated method stub
		// ruijieliuliang,ruijietaocan,aoxiang,xiache,xiaoli,paocao;

		mobView = new WebView(getActivity());

		mobView.getSettings().setJavaScriptEnabled(true);

		ruijieliuliang = (ImageView) layoutoftryView
				.findViewById(R.id.image_ruijiechaxun);
		ruijietaocan = (ImageView) layoutoftryView
				.findViewById(R.id.image_ruijietaocan);

		aoxiang = (ImageView) layoutoftryView.findViewById(R.id.image_aoxiang);
		xiaoche = (ImageView) layoutoftryView.findViewById(R.id.image_xiaoche);
		xiaoli = (ImageView) layoutoftryView.findViewById(R.id.image_xiaoli);
		paocao = (ImageView) layoutoftryView.findViewById(R.id.image_paocao);

		aoxiang.setOnClickListener(this);
		xiaoche.setOnClickListener(this);
		xiaoli.setOnClickListener(this);

		paocao.setOnClickListener(this);
		ruijietaocan.setOnClickListener(this);
		ruijieliuliang.setOnClickListener(this);

	}

	void open(String uri) {
		Intent intent = new Intent();
		// Intent intent = new Intent(Intent.ACTION_VIEW,uri);
		intent.setAction("android.intent.action.VIEW");
		Uri content_url = Uri.parse(uri);
		intent.setData(content_url);
		startActivity(intent);

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub

		switch (v.getId()) {
		case R.id.image_aoxiang:

			System.out.println(111);
			open("https://uis.nwpu.edu.cn/cas/login?service=https%3A%2F%2Fecampus.nwpu.edu.cn%2Fc%2Fportal%2Flogin%3Fredirect%3D%252Fc");

			break;

		case R.id.image_paocao:

			open("http://tiyu.nwpu.edu.cn/");

			break;
		case R.id.image_ruijiechaxun:

			open("http://self.nwpu.edu.cn:8080/selfservice/");

			break;
		case R.id.image_ruijietaocan:
			open("https://wszf.nwpu.edu.cn/login.aspx");

			break;
		case R.id.image_xiaoche:
			open("http://xygg.nwpu.edu.cn/info/1003/15342.htm");

			break;
		case R.id.image_xiaoli:
			open("http://xygg.nwpu.edu.cn/info/1003/18510.htm");

			break;
		default:
			break;
		}

	}
}
