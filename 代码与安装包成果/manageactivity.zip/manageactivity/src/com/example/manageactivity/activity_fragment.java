package com.example.manageactivity;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import com.nostra13.universalimageloader.cache.disc.impl.UnlimitedDiscCache;
import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator;
import com.nostra13.universalimageloader.cache.memory.impl.UsingFreqLimitedMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.ImageLoadingListener;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;
import com.nostra13.universalimageloader.core.assist.SimpleImageLoadingListener;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;
import com.nostra13.universalimageloader.core.download.BaseImageDownloader;
import com.nostra13.universalimageloader.utils.StorageUtils;

import login_and_register.ff.R;
import login_and_register.ff.register;
import mine.ActivityOnMainListViewAdapter;
import mine.CollectListViewAdapter;
import mine.SignedListViewAdapter;
import mine.mine_collected;
import mine.mine_collected.DataThread;
import webservice.Constants;
import webservice.webservice_activity_fragment;
import zrc.widget.SimpleFooter;
import zrc.widget.SimpleHeader;
import zrc.widget.ZrcListView;
import zrc.widget.ZrcListView.OnStartListener;
import android.R.anim;
import android.R.integer;
import android.content.Intent;
import android.database.DataSetObserver;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SearchView;
import android.widget.SearchView.OnCloseListener;
import android.widget.SearchView.OnQueryTextListener;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class activity_fragment extends Fragment {

	String stuID = null;

	View layoutoftryView;
	SearchView search;
	Spinner spinnerofactivity;
	Spinner spinnerofschool;
	// ListView listview_activity;
	private ListView actListView;
	private ActivityOnMainListViewAdapter actListViewAdapter;

	Button button1;
	// �����ŷ�������õ�activity��Ϣ
	ArrayList<String> listname = new ArrayList<String>();
	ArrayList<String> listintrodution = new ArrayList<String>();
	ArrayList<String> listid = new ArrayList<String>();
	ArrayList<String> listlocation = new ArrayList<String>();
	ArrayList<String> listdepartment = new ArrayList<String>();
	ArrayList<String> listcategory = new ArrayList<String>();

	ArrayList<String> listactivitytype = new ArrayList<String>();

	ArrayList<String> listacademy = new ArrayList<String>();
	ArrayList<String> listImg = new ArrayList<String>();

	// mine
	ArrayList<activity> activitylist = new ArrayList<activity>();

	// ����ȷ����activity��Ϣ
	ArrayList<String> final_name = new ArrayList<String>();
	ArrayList<String> final_introdution = new ArrayList<String>();
	ArrayList<String> final_id = new ArrayList<String>();
	ArrayList<String> final_location = new ArrayList<String>();
	ArrayList<String> final_department = new ArrayList<String>();
	ArrayList<String> final_category = new ArrayList<String>();
	ArrayList<String> final_img = new ArrayList<String>();

	private ImageView imageView;

	/******************************************** 20170430 *********************************************/
	private DisplayImageOptions options; // ͼƬ�첽����
	private ImageLoadingListener animateFirstListener = new AnimateFirstDisplayListener();
	protected ImageLoader imageLoader = ImageLoader.getInstance();

	/******************************************** 20170430 *********************************************/

	ProgressBar p;

	@Override
	public View onCreateView(LayoutInflater inflater,
			@Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		// TODO Auto-generated method stub

		layoutoftryView = inflater.inflate(R.layout.activity_fragment,
				container, false);

		stuID = getActivity().getIntent().getExtras().getString("StudentId");
		initAscnyImgOption();
		init();

		p.setVisibility(0);

		getdata();
		// /

		String server = Constants.serverPath + "get_act_img?imgurl=";

		String imgNames = listImg.get(1);
		// Toast.makeText(getActivity(), imgNames, Toast.LENGTH_LONG).show();

		imgNames = imgNames.replace("|", "/");
		String[] imgUrls = imgNames.split("/");
		// Toast.makeText(getActivity(), server + imgUrls[0],
		// Toast.LENGTH_LONG).show();

		imageLoader.displayImage(server + imgUrls[0], imageView, options,
				animateFirstListener);

		// //

		for (String a : listacademy) {
			System.out.println("W+" + a);
		}
		setadapter();
		spinnerofactivity.setSelection(0, true);
		spinnerofschool.setSelection(0, true);

		for (int j = 0; j < listid.size(); j++) {

			activity a = new activity();

			a.setactivityId(listid.get(j));
			a.setdepartment(listdepartment.get(j));
			a.setintroduction(listintrodution.get(j));
			a.setlocation(listlocation.get(j));
			a.setname(listname.get(j));
			a.setImg(listImg.get(j));

			activitylist.add(a);

		}

		p.setVisibility(8);
		// �����ʵ��
		search.setOnCloseListener(new OnCloseListener() {

			@Override
			public boolean onClose() {
				// TODO Auto-generated method stub
				return false;
			}
		});
		search.setOnQueryTextListener(new OnQueryTextListener() {

			@Override
			public boolean onQueryTextSubmit(String query) {
				// TODO Auto-generated method stub

				ArrayList<activity> focusactivitylist = new ArrayList<activity>();
				if (!query.equals("")) {
					for (int i = 0; i < listname.size(); i++) {

						if (listname.get(i).indexOf(query) != -1) {

							focusactivitylist.add(activitylist.get(i));
							System.out.println(activitylist.get(i).getName());
						}

					}

					ArrayList<String> q_name = new ArrayList<String>();
					ArrayList<String> q_introdution = new ArrayList<String>();
					ArrayList<String> q_id = new ArrayList<String>();
					ArrayList<String> q_location = new ArrayList<String>();
					ArrayList<String> q_department = new ArrayList<String>();
					ArrayList<String> q_img = new ArrayList<String>();
					// System.out.println("111");
					for (int k = 0; k < focusactivitylist.size(); k++) {

						q_name.add(focusactivitylist.get(k).getName());
						q_introdution.add(focusactivitylist.get(k)
								.getIntroduction());
						q_id.add(focusactivitylist.get(k).getActivityId());
						q_location.add(focusactivitylist.get(k).getLocation());
						q_department.add(focusactivitylist.get(k)
								.getDepartment());
						q_img.add(focusactivitylist.get(k).getImg());

					}

					// for (String string : name) {
					// System.out.println(string);
					//
					// }

					actListViewAdapter = new ActivityOnMainListViewAdapter(
							getActivity(), q_name, q_location, q_department,
							q_introdution, q_id, q_img);
					actListView.setAdapter(actListViewAdapter);
					// Ĭ����ʾ��������ListView����Ҫ�ֶ���ScrollView���������
					setListViewHeightBasedOnChildren(actListView);
					ScrollView sv = (ScrollView) layoutoftryView
							.findViewById(R.id.scrollViewInIndex);
					sv.smoothScrollTo(0, 0);

				} else {

				}

				return false;

			}

			@Override
			public boolean onQueryTextChange(String newText) {
				// TODO Auto-generated method stub
				return false;
			}
		});

		// ѧԺɸѡ ��������
		spinnerofschool.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				String selectedSchool = listacademy.get(position);
				if (selectedSchool.equals("ȫ��")) {
					for (int i = 0; i < listname.size(); i++) {

						// final_category.add(listcategory.get(i).toString());
						final_name.add(listname.get(i).toString());
						final_introdution
								.add(listintrodution.get(i).toString());
						final_id.add(listid.get(i).toString());
						final_location.add(listlocation.get(i).toString());
						final_department.add(listdepartment.get(i).toString());
						final_img.add(listImg.get(i).toString());

					}

				} else {

					clearArrayList();

					for (int i = 0; i < listname.size(); i++) {
						if (listdepartment.get(i).toString()
								.contains(selectedSchool)) {
							// final_category.add(listcategory.get(i).toString());
							final_name.add(listname.get(i).toString());
							final_introdution.add(listintrodution.get(i)
									.toString());
							final_id.add(listid.get(i).toString());
							final_location.add(listlocation.get(i).toString());
							final_department.add(listdepartment.get(i)
									.toString());
							final_img.add(listImg.get(i).toString());
						}
					}

				}

				setadapterofListView();
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub
				nothingSelected();
			}
		});
		spinnerofactivity
				.setOnItemSelectedListener(new OnItemSelectedListener() {
					@Override
					public void onItemSelected(AdapterView<?> arg0, View arg1,
							int position, long arg3) {
						// TODO Auto-generated method stub
						clearArrayList();
						String selectedType = listactivitytype.get(position);
						System.out.println(selectedType + "selected"
								+ listcategory.size());

						for (int i = 0; i < listname.size(); i++) {

							System.out.println(listcategory.get(i).toString());

							if (listcategory.get(i).toString()
									.contains(selectedType)) {

								System.out.println(listname.get(i).toString());

								final_category.add(listcategory.get(i)
										.toString());
								final_name.add(listname.get(i).toString());
								final_introdution.add(listintrodution.get(i)
										.toString());
								final_id.add(listid.get(i).toString());
								final_location.add(listlocation.get(i)
										.toString());
								final_department.add(listdepartment.get(i)
										.toString());
								final_img.add(listImg.get(i).toString());
							}
						}
						setadapterofListView();
					}

					@Override
					public void onNothingSelected(AdapterView<?> arg0) {
						// TODO Auto-generated method stub
						nothingSelected();
						// setadapterofListView();
					}
				});
		// ��ĵ���¼�
		actListView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				System.out.println(position);
				TextView t = (TextView) view
						.findViewById(R.id.activity_f_act_name);
				String name = t.getText().toString();
				System.out.println(name);
				int n = 0;
				for (int i = 0; i < listname.size(); i++) {
					if (listname.get(i).equals(name)) {
						n = i;
						break;
					}

				}
				System.out.println(n);
				Intent intent = new Intent();
				intent.setClass(getActivity(), activity_info.class);
				intent.putExtra("StudentId", stuID);
				intent.putExtra("introduction", listintrodution.get(n));
				intent.putExtra("activityId", listid.get(n));
				intent.putExtra("activityImg", listImg.get(n));

				getActivity().startActivity(intent);

				// getActivity().finish();

			}
		});
		return layoutoftryView;

	}

	private void nothingSelected() {
		// final_category = (ArrayList<String>) listcategory.clone();
		final_name = (ArrayList<String>) listname.clone();
		final_introdution = (ArrayList<String>) listintrodution.clone();
		final_id = (ArrayList<String>) listid.clone();
		final_location = (ArrayList<String>) listlocation.clone();
		final_department = (ArrayList<String>) listdepartment.clone();
		final_img = (ArrayList<String>) listImg.clone();
	}

	private void clearArrayList() {
		final_category.clear();
		final_department.clear();
		final_id.clear();
		final_introdution.clear();
		final_location.clear();
		final_name.clear();
		final_img.clear();
	}

	// �����÷�����������
	private void getdata() {
		// TODO Auto-generated method stub

		webservice_activity_fragment webse = new webservice_activity_fragment();

		int i = 1, j = 1, h = 1;
		try {

			// actvity
			while (!webse.getinfo(Integer.toString(i)).equals("no activity")) {

				System.out.println(webse.getinfo(Integer.toString(i)));
				String introduction, id, department, location, name, category, img;

				String[] info = webse.getinfo(Integer.toString(i)).split(" ");

				name = info[0];
				department = info[1];
				introduction = info[2];
				location = info[3];
				category = info[4];
				id = Integer.toString(i);
				img = info[5];
				// Toast.makeText(getActivity(), img, Toast.LENGTH_LONG).show();
				listintrodution.add(introduction);
				listid.add(id);
				listlocation.add(location);
				listname.add(name);
				listdepartment.add(department);

				System.out.println(1 + category);
				listcategory.add(category);
				listImg.add(img);
				i++;

			}

			// listactivitytype.add("ȫ��"); // 20170321 add
			// category
			while (!webse.getcategory(Integer.toString(j))
					.equals("no category")) {

				String name;

				name = webse.getcategory(Integer.toString(j));
				listactivitytype.add(name);

				j++;

			}

			listacademy.add("ȫ��"); // 20170321 add
			// academy
			while (!webse.getacademy(Integer.toString(h)).equals("no academy")) {

				String name;

				name = webse.getacademy(Integer.toString(h));
				listacademy.add(name);

				h++;

			}

		} catch (Exception e) {
			// TODO: handle exception

		}

	}

	private void setadapter() {
		// TODO Auto-generated method stub
		spinnerofactivity.setAdapter(getactivityadapter());
		spinnerofschool.setAdapter(getschooladapter());
		actListView.setAdapter(getlist_activity_adapter());
		// Ĭ����ʾ��������ListView����Ҫ�ֶ���ScrollView���������
		setListViewHeightBasedOnChildren(actListView);
		ScrollView sv = (ScrollView) layoutoftryView
				.findViewById(R.id.scrollViewInIndex);
		sv.smoothScrollTo(0, 0);

	}

	private void setadapterofListView() {
		actListView.setAdapter(getlist_activity_adapter());
		// Ĭ����ʾ��������ListView����Ҫ�ֶ���ScrollView���������
		setListViewHeightBasedOnChildren(actListView);
		ScrollView sv = (ScrollView) layoutoftryView
				.findViewById(R.id.scrollViewInIndex);
		sv.smoothScrollTo(0, 0);
	}

	// ��Ҫ����
	private ActivityOnMainListViewAdapter getlist_activity_adapter() {
		// TODO Auto-generated method stub

		actListViewAdapter = new ActivityOnMainListViewAdapter(getActivity(),
				final_name, final_location, final_department,
				final_introdution, final_id, final_img);

		// ArrayAdapter LA = new ArrayAdapter<String>(this.getActivity(),
		// android.R.layout.simple_list_item_1, final_name);
		return actListViewAdapter;

	}

	private void init() {

		// TODO Auto-generated method stub
		spinnerofactivity = (Spinner) layoutoftryView
				.findViewById(R.id.spinner_activity_type);

		spinnerofschool = (Spinner) layoutoftryView
				.findViewById(R.id.spinner_college);

		actListView = ((ListView) layoutoftryView
				.findViewById(R.id.listView_f_activity));

		// button1 = (Button) layoutoftryView.findViewById(R.id.button_1);

		search = (SearchView) layoutoftryView.findViewById(R.id.searchView);

		imageView = (ImageView) layoutoftryView
				.findViewById(R.id.imageView_index_activity);
		p = (ProgressBar) layoutoftryView.findViewById(R.id.register_wait_bar);

	}

	// ��ѧԺspinner����adapter���ú����ݿ⽻��

	private ArrayAdapter<String> getschooladapter() {
		// TODO Auto-generated method stub

		ArrayAdapter<String> ad = new ArrayAdapter(this.getActivity(),
				android.R.layout.simple_spinner_item, listacademy);
		ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		return ad;
	}

	// �������spinner����adapter���ý���
	private ArrayAdapter<String> getactivityadapter() {
		// TODO Auto-generated method stub

		ArrayAdapter<String> ad = new ArrayAdapter(this.getActivity(),
				android.R.layout.simple_spinner_item, listactivitytype);
		ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		return ad;
	}

	private void initAscnyImgOption() {
		File cacheDir = StorageUtils
				.getOwnCacheDirectory(getActivity().getApplicationContext(),
						"/ActivityManager/users/images/Cache");
		ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(
				getActivity())
				.memoryCacheExtraOptions(480, 800)
				// max width, max height���������ÿ�������ļ�����󳤿�
				.discCacheExtraOptions(480, 800, CompressFormat.JPEG, 75, null)
				// Can slow ImageLoader, use it carefully (Better don't use
				// it)/���û������ϸ��Ϣ����ò�Ҫ�������
				.threadPoolSize(3)
				// �̳߳��ڼ��ص�����
				.threadPriority(Thread.NORM_PRIORITY - 2)
				.denyCacheImageMultipleSizesInMemory()
				.memoryCache(new UsingFreqLimitedMemoryCache(2 * 1024 * 1024))
				// You can pass your own memory cache
				// implementation/�����ͨ���Լ����ڴ滺��ʵ��
				.memoryCacheSize(2 * 1024 * 1024)
				.discCacheSize(50 * 1024 * 1024)
				.discCacheFileNameGenerator(new Md5FileNameGenerator())
				// �������ʱ���URI������MD5 ����
				.tasksProcessingOrder(QueueProcessingType.LIFO)
				.discCacheFileCount(100)
				// ������ļ�����
				.discCache(new UnlimitedDiscCache(cacheDir))
				// �Զ��建��·��
				.defaultDisplayImageOptions(DisplayImageOptions.createSimple())
				.imageDownloader(
						new BaseImageDownloader(getActivity(), 5 * 1000,
								30 * 1000)) // connectTimeout
				// (5
				// s),
				// readTimeout
				// (30
				// s)��ʱʱ��
				.writeDebugLogs() // Remove for release app
				.build();// ��ʼ����

		ImageLoader.getInstance().init(config);// ȫ�ֳ�ʼ��������

		options = new DisplayImageOptions.Builder()
				.showImageOnLoading(R.drawable.ic_stub)
				.showImageForEmptyUri(R.drawable.ic_empty)
				.showImageOnFail(R.drawable.ic_error).cacheInMemory(true)
				.cacheOnDisc(true).considerExifParams(true)
				.displayer(new RoundedBitmapDisplayer(20)).build();
	}

	private static class AnimateFirstDisplayListener extends
			SimpleImageLoadingListener {

		static final List<String> displayedImages = Collections
				.synchronizedList(new LinkedList<String>());

		@Override
		public void onLoadingComplete(String imageUri, View view,
				Bitmap loadedImage) {
			if (loadedImage != null) {
				ImageView imageView = (ImageView) view;
				boolean firstDisplay = !displayedImages.contains(imageUri);
				if (firstDisplay) {
					FadeInBitmapDisplayer.animate(imageView, 500);
					displayedImages.add(imageUri);
				}
			}
		}
	}

	/**
	 * ����ListView�ĸ߶ȣ����ScrollViewǶ��ListView����
	 * 
	 * @param listView
	 */
	private void setListViewHeightBasedOnChildren(ListView listView) {

		ListAdapter listAdapter = listView.getAdapter();
		if (listAdapter == null) {
			return;
		}

		int totalHeight = 0;
		for (int i = 0; i < listAdapter.getCount(); i++) {
			View listItem = listAdapter.getView(i, null, listView);
			listItem.measure(0, 0);
			totalHeight += listItem.getMeasuredHeight();
		}

		ViewGroup.LayoutParams params = listView.getLayoutParams();
		params.height = totalHeight
				+ (listView.getDividerHeight() * (listAdapter.getCount() - 1));
		listView.setLayoutParams(params);
	}
}
